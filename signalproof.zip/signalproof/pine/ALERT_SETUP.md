# Wiring TradingView alerts into SignalProof

Two paths, depending on whether you control the script.

## Requirements

- A paid TradingView plan (webhook notifications are a paid feature).
- The logger running on an HTTPS URL (see README: ngrok for testing,
  Railway/Render/VPS for real audits).
- Your webhook URL: `https://<your-host>/webhook/<SP_SECRET>`

## Path A — your own indicator

Use `signalproof_wrapper.pine`: paste your signal logic into the marked block,
set the `SignalProof slug` input, add the script to the chart, then create
**one alert** with:

- **Condition:** your script → *Any alert() function call*
- **Options:** Once per bar close (the wrapper already enforces this)
- **Notifications:** Webhook URL → your logger URL
- **Expiration:** open-ended

## Path B — a third-party / invite-only indicator (the audit case)

You can't edit the code, but you can attach alerts to its plots exactly like
any paying subscriber. For each signal direction:

1. Add the indicator to the chart (request access first if invite-only).
2. Create an alert. **Condition:** the indicator's Buy plot/alert condition
   (e.g. `Quantum BuySell Pro → Buy`). Trigger: **Once per bar close**.
3. Paste this as the **message** (edit `indicator` and `signal` per alert):

```json
{"indicator":"quantum-buysell-pro","signal":"BUY","symbol":"{{ticker}}","exchange":"{{exchange}}","interval":"{{interval}}","price":"{{close}}","bar_time":"{{time}}","alert_time":"{{timenow}}"}
```

4. Enable **Webhook URL** and paste your logger URL.
5. Repeat with `"signal":"SELL"` on the Sell condition.

`{{time}}` is the open time of the bar that triggered the alert — that is the
key that lets the diff tool line live signals up against the chart export.

## After the monitoring window (2–4 weeks)

1. On the same chart/timeframe, use **Export chart data…** to get the CSV
   (it contains `time`, OHLC, and one column per plotted series).
2. Download the live log: `https://<host>/signals?indicator=<slug>&fmt=csv`
3. Run the pipeline (see README quickstart) — repaint check, forward stats,
   report.

## Audit hygiene (what makes the result defensible)

- Note the exact script version/date you added, and screenshot the chart at
  the start and end of the window.
- Don't touch the alert or the chart settings mid-window; if TradingView
  pauses an alert (server maintenance, plan limits), log it and state the gap
  in the report.
- One symbol + one timeframe per audit. Run parallel charts for more coverage.
- Keep the SQLite file backed up; the hash chain makes edits detectable, and
  backups make losses recoverable.
