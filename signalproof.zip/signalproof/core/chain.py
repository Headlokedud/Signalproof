"""Tamper-evident hash chain for SignalProof logs.

Every logged signal row carries row_hash = SHA-256 over the previous row's
hash plus the row's own canonical fields. Re-computing the chain from the
raw export proves no row was edited, deleted, or inserted after the fact.
"""
import hashlib

GENESIS = "GENESIS"

FIELDS = [
    "received_at", "indicator", "symbol", "exchange", "interval",
    "signal", "price_raw", "bar_time", "alert_time", "raw",
]


def row_hash(prev_hash: str, row: dict) -> str:
    """Canonical hash for one signal row. `row` values may be None."""
    parts = [prev_hash or GENESIS]
    for f in FIELDS:
        v = row.get(f)
        parts.append("" if v is None else str(v))
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


def verify_chain(rows: list) -> dict:
    """Walk rows (ascending insert order) and recompute the chain.

    Each row must contain FIELDS plus prev_hash and row_hash.
    Returns {"intact": bool, "checked": int, "first_bad_index": int|None}.
    """
    prev = GENESIS
    for i, r in enumerate(rows):
        if (r.get("prev_hash") or GENESIS) != prev:
            return {"intact": False, "checked": i, "first_bad_index": i}
        expect = row_hash(prev, r)
        if r.get("row_hash") != expect:
            return {"intact": False, "checked": i, "first_bad_index": i}
        prev = r["row_hash"]
    return {"intact": True, "checked": len(rows), "first_bad_index": None}
