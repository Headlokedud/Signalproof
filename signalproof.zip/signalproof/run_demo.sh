#!/usr/bin/env bash
# End-to-end demo: repaint check + forward stats + report for both demo audits.
set -e
cd "$(dirname "$0")"

python3 tools/repaint_check.py --live data/demo/aurora_live.csv \
  --chart data/demo/aurora_chart.csv --indicator aurora-trend-suite \
  --buy-col Buy --sell-col Sell --out reports/aurora_repaint.json

python3 tools/forward_stats.py --live data/demo/aurora_live.csv \
  --ohlc data/demo/aurora_chart.csv --indicator aurora-trend-suite \
  --horizons 1,5,10,20 --cost-bps 5 --out reports/aurora_stats.json

python3 tools/make_report.py --indicator aurora-trend-suite \
  --name "Aurora Trend Suite" --vendor "Sindre Capital" \
  --market "OANDA:XAUUSD · 1H" --live data/demo/aurora_live.csv \
  --repaint reports/aurora_repaint.json --stats reports/aurora_stats.json \
  --out reports/aurora-trend-suite.html

python3 tools/repaint_check.py --live data/demo/quantum_live.csv \
  --chart data/demo/quantum_chart.csv --indicator quantum-buysell-pro \
  --buy-col Buy --sell-col Sell --out reports/quantum_repaint.json

python3 tools/forward_stats.py --live data/demo/quantum_live.csv \
  --ohlc data/demo/quantum_chart.csv --indicator quantum-buysell-pro \
  --horizons 1,5,10,20 --cost-bps 5 --out reports/quantum_stats.json

python3 tools/make_report.py --indicator quantum-buysell-pro \
  --name "Quantum BuySell Pro" --vendor "Undisclosed vendor" \
  --market "OANDA:NAS100USD · 1H" --live data/demo/quantum_live.csv \
  --repaint reports/quantum_repaint.json --stats reports/quantum_stats.json \
  --out reports/quantum-buysell-pro.html

echo "Done. Open reports/aurora-trend-suite.html and reports/quantum-buysell-pro.html"
