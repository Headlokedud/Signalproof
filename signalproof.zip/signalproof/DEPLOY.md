# Deploying the SignalProof logger

Goal: a stable HTTPS URL that TradingView can post alerts to, 24/7, for weeks.
Total time: ~20 minutes. Cost: $0–5/month.

## Before you start

Generate a secret (this goes in the webhook URL, so make it long):

```bash
openssl rand -hex 24
```

push the project to a **public** GitHub repo (open-source tooling is part of the trust pitch; the secret lives only in Railway env vars, never in the repo):

```bash
cd signalproof
git init && git add . && git commit -m "SignalProof v0.1"
# create a public repo on github.com, then:
git remote add origin git@github.com:<you>/signalproof.git
git push -u origin main
```

## Option A — Railway (recommended)

1. railway.com → **New Project → Deploy from GitHub repo** → pick `signalproof`.
   It auto-detects the Dockerfile.
2. **Add a volume** (right-click the service → Attach Volume). Mount path:
   `/data`. Without this, the SQLite log is wiped on every redeploy — the one
   thing an audit service can't survive.
3. Service → **Variables**: add `SP_SECRET` = your generated secret.
4. Service → **Settings → Networking → Generate Domain**. Note the URL,
   e.g. `https://signalproof-production.up.railway.app`.
5. Health check (optional but nice): Settings → Health Check Path = `/health`.

## Option B — Render

New → **Web Service** → connect the repo → Runtime: Docker.
Add a **Disk** mounted at `/data` (1 GB is plenty). Env var `SP_SECRET`.
Note: Render free tier sleeps on idle and has no disks — use the cheapest
paid instance for real audits.

## Option C — quick local test (not for real audits)

```bash
SP_SECRET=test uvicorn server.main:app --port 8000
ngrok http 8000
```

ngrok URLs change on restart, so this is only for verifying the wiring.

## Post-deploy checklist (2 minutes)

```bash
BASE=https://<your-domain>
SECRET=<your-secret>

curl $BASE/health
# {"ok":true,...}

curl -X POST $BASE/webhook/$SECRET -H 'Content-Type: application/json' \
  -d '{"indicator":"deploy-test","signal":"BUY","symbol":"XAUUSD","exchange":"OANDA","interval":"60","price":"2400.00","bar_time":"2026-06-11T08:00:00Z","alert_time":"2026-06-11T09:00:01Z"}'
# {"ok":true,"parsed_json":true,...}

curl $BASE/verify/deploy-test
# {"intact":true,...}
```

Open `$BASE/` in a browser — the dashboard should show the test signal.
Your TradingView webhook URL is `$BASE/webhook/$SECRET`
(setup steps in `pine/ALERT_SETUP.md`).

## Operating notes

- **Backups:** once a week, download
  `$BASE/signals?fmt=csv` and keep the file. The hash chain makes tampering
  detectable; backups make loss recoverable.
- **Don't redeploy mid-audit** unless you must — the volume keeps data safe,
  but a deploy gap could miss an alert. If it happens, note the gap in the
  report (the README's honesty rules cover this).
- **Rotating the secret** = changing every TradingView alert's webhook URL.
  Pick a good one now.
- TradingView pauses alerts in some cases (plan limits, script updates by the
  vendor). Glance at the dashboard every couple of days during a window.
