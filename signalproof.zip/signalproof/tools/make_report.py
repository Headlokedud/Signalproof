"""SignalProof report card generator.

Renders a single-file, public-facing HTML audit certificate from:
  --live     the logger's CSV export (used for the signal log + hash chain)
  --repaint  repaint_check.py verdict JSON
  --stats    forward_stats.py JSON (optional)

Usage:
  python tools/make_report.py \
      --indicator aurora-trend-suite --name "Aurora Trend Suite" \
      --vendor "Sindre Capital" --market "OANDA:XAUUSD · 1H" \
      --live data/demo/aurora_live.csv \
      --repaint reports/aurora_repaint.json \
      --stats reports/aurora_stats.json \
      --out reports/aurora-trend-suite.html
"""
import argparse
import hashlib
import html
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core.chain import verify_chain  # noqa: E402


def esc(v) -> str:
    return html.escape("" if v is None else str(v))


def short_hash(h: str | None) -> str:
    if not h:
        return "—"
    return f"{h[:10]}…{h[-10:]}" if len(h) > 24 else h


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--indicator", required=True, help="slug used in the log")
    ap.add_argument("--name", required=True, help="display name")
    ap.add_argument("--vendor", default="Undisclosed vendor")
    ap.add_argument("--market", default="", help='e.g. "OANDA:XAUUSD · 1H"')
    ap.add_argument("--live", required=True)
    ap.add_argument("--repaint", required=True)
    ap.add_argument("--stats", default=None)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rep = json.loads(Path(args.repaint).read_text())
    stats = json.loads(Path(args.stats).read_text()) if args.stats else None

    live = pd.read_csv(args.live, dtype=str)
    live = live[live["indicator"] == args.indicator]
    rows = live.to_dict("records")
    chain = verify_chain(rows) if rows else {"intact": False, "checked": 0}

    verdict = rep.get("verdict", "FAIL")
    counts = rep.get("counts", {})
    window = rep.get("monitored_window_utc", {})
    w_start, w_end = window.get("start", ""), window.get("end", "")
    try:
        days = max(1, (pd.Timestamp(w_end) - pd.Timestamp(w_start)).days)
    except Exception:
        days = "—"

    issued = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    rid = "SP-" + hashlib.sha256(
        f"{args.indicator}|{w_start}|{w_end}".encode()).hexdigest()[:8].upper()

    if verdict == "PASS":
        stamp_text, vclass = "Verified · no repaint", "pass"
        verdict_line = ("Every live-recorded signal is still on the chart, and no "
                        "signal was added to history inside the monitored window.")
    elif verdict == "WARN":
        stamp_text, vclass = "Inconclusive", "warn"
        verdict_line = ("Minor discrepancies were found. They may stem from data-feed "
                        "differences; treat historical performance with caution.")
    else:
        stamp_text, vclass = "Repaint detected", "fail"
        verdict_line = ("The indicator's chart history does not match what it signalled "
                        "in real time. Historical signals are not what a live subscriber saw.")

    # --- discrepancy / log rows -------------------------------------------
    def sig_rows(items, tag, tag_class, cap=10):
        out = []
        for it in items[:cap]:
            out.append(
                f'<tr><td>{esc(it.get("bar_time"))}</td>'
                f'<td>{esc(it.get("direction"))}</td>'
                f'<td>{esc(it.get("received_at") or "—")}</td>'
                f'<td><span class="tag {tag_class}">{tag}</span></td></tr>')
        if len(items) > cap:
            out.append(f'<tr><td colspan="4" class="more">+ {len(items) - cap} '
                       f'more in the evidence file</td></tr>')
        return "".join(out)

    disc_rows = (sig_rows(rep.get("vanished", []), "Vanished", "t-fail")
                 + sig_rows(rep.get("appeared", []), "Backfilled", "t-warn"))

    if disc_rows:
        discrepancy_block = f"""
      <table>
        <thead><tr><th>Bar time (UTC)</th><th>Direction</th>
        <th>Logged live at</th><th>Finding</th></tr></thead>
        <tbody>{disc_rows}</tbody>
      </table>"""
    else:
        discrepancy_block = (f'<p class="clean">0 discrepancies across '
                             f'{esc(counts.get("live_signals", 0))} live-recorded '
                             f'signals. History matches the live record exactly.</p>')

    sample = rows[:3] + (rows[-3:] if len(rows) > 6 else rows[3:])
    sample_rows = "".join(
        f'<tr><td>{esc(r.get("received_at"))}</td><td>{esc(r.get("signal"))}</td>'
        f'<td>{esc(r.get("symbol"))} · {esc(r.get("interval"))}</td>'
        f'<td>{esc(r.get("price_raw"))}</td>'
        f'<td class="mono-dim">{esc(short_hash(r.get("row_hash")))}</td></tr>'
        for r in sample)

    # --- forward stats -----------------------------------------------------
    stats_block = ""
    if stats and stats.get("horizons_bars"):
        srows = "".join(
            f'<tr><td>{esc(h)}</td><td>{st["trades"]}</td>'
            f'<td>{st["win_rate_pct"]}%</td><td>{st["avg_return_pct"]}%</td>'
            f'<td>{st["median_return_pct"]}%</td>'
            f'<td>{st["worst_pct"]}%</td></tr>'
            for h, st in stats["horizons_bars"].items())
        stats_block = f"""
    <section>
      <h2><span class="sec-no">03</span>Forward performance</h2>
      <p>Computed only from signals that were server-timestamped <em>before</em>
      their outcome existed — a true forward test. Entry: {esc(stats.get("entry_rule"))},
      round-trip cost {esc(stats.get("cost_bps_round_trip"))} bps.
      {stats.get("buy_signals", 0)} buy / {stats.get("sell_signals", 0)} sell signals.</p>
      <table>
        <thead><tr><th>Horizon (bars)</th><th>Trades</th><th>Win rate</th>
        <th>Avg return</th><th>Median</th><th>Worst</th></tr></thead>
        <tbody>{srows}</tbody>
      </table>
      <p class="fine">Per-trade, direction-adjusted returns. No position sizing or
      overlap handling; a positive average here is necessary, not sufficient.</p>
    </section>"""

    chain_state = ("Intact — every row re-hashes correctly"
                   if chain.get("intact") else "BROKEN — log failed re-verification")
    first_hash = rows[0].get("row_hash") if rows else None
    last_hash = rows[-1].get("row_hash") if rows else None

    figures = [
        ("Days monitored", days, ""),
        ("Live signals logged", counts.get("live_signals", 0), ""),
        ("Vanished from history", counts.get("vanished", 0),
         " f-fail" if counts.get("vanished", 0) else ""),
        ("Backfilled into history", counts.get("appeared", 0),
         " f-warn" if counts.get("appeared", 0) else ""),
    ]
    figures_html = "".join(
        f'<div class="fig{cls}"><div class="fig-v">{esc(v)}</div>'
        f'<div class="fig-l">{esc(label)}</div></div>'
        for label, v, cls in figures)

    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(args.name)} — SignalProof audit {rid}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@600;900&family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {{
  --paper:#ECEFF3; --panel:#FAFBFD; --ink:#0F1B2D; --muted:#5A6B85;
  --line:#C6CFDB; --pass:#0E7B4F; --fail:#B3362B; --warn:#B26B00;
}}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--paper); color:var(--ink);
  font:16px/1.65 "IBM Plex Sans", system-ui, sans-serif; }}
.doc {{ max-width:880px; margin:0 auto; padding:28px 22px 60px; }}
a {{ color:inherit; }}
a:focus-visible {{ outline:3px solid var(--ink); outline-offset:2px; }}

.meta-bar {{ display:flex; justify-content:space-between; gap:12px;
  font:600 12px/1 "IBM Plex Mono", monospace; letter-spacing:.08em;
  text-transform:uppercase; color:var(--muted);
  border-bottom:2px solid var(--ink); padding-bottom:12px; }}
.meta-bar b {{ color:var(--ink); }}

.hero {{ position:relative; padding:42px 0 30px; border-bottom:2px solid var(--ink); }}
.kicker {{ font:600 12px/1 "IBM Plex Mono", monospace; letter-spacing:.18em;
  text-transform:uppercase; color:var(--muted); margin:0 0 14px; }}
h1 {{ font:900 clamp(34px,6vw,54px)/1.02 Archivo, sans-serif;
  letter-spacing:-.01em; margin:0 0 10px; max-width:12em; }}
.sub {{ font:400 15px/1.5 "IBM Plex Mono", monospace; color:var(--muted); margin:0; }}

.stamp {{ position:absolute; right:0; top:46px; transform:rotate(-7deg);
  font:900 clamp(15px,2.4vw,21px)/1.15 Archivo, sans-serif;
  letter-spacing:.06em; text-transform:uppercase; text-align:center;
  padding:14px 20px; max-width:240px; border:3px solid currentColor;
  border-radius:8px; box-shadow:0 0 0 4px var(--paper), 0 0 0 6px currentColor; }}
.stamp small {{ display:block; font:600 10px/1 "IBM Plex Mono", monospace;
  letter-spacing:.2em; margin-top:7px; }}
.pass  {{ color:var(--pass); }}
.fail  {{ color:var(--fail); }}
.warn  {{ color:var(--warn); }}

.verdict-line {{ font-size:17px; max-width:36em; margin:22px 0 0; }}
.verdict-line b {{ font-weight:600; }}

.figs {{ display:grid; grid-template-columns:repeat(4,1fr); gap:14px;
  padding:24px 0; border-bottom:2px solid var(--ink); }}
.fig {{ border-top:3px solid var(--ink); padding-top:10px; }}
.fig-v {{ font:900 34px/1 Archivo, sans-serif; }}
.fig-l {{ font:600 11px/1.35 "IBM Plex Mono", monospace; letter-spacing:.1em;
  text-transform:uppercase; color:var(--muted); margin-top:6px; }}
.f-fail .fig-v {{ color:var(--fail); }} .f-fail {{ border-top-color:var(--fail); }}
.f-warn .fig-v {{ color:var(--warn); }} .f-warn {{ border-top-color:var(--warn); }}

section {{ padding:30px 0 6px; border-bottom:1px solid var(--line); }}
h2 {{ font:900 19px/1.2 Archivo, sans-serif; letter-spacing:.02em;
  text-transform:uppercase; margin:0 0 12px; }}
.sec-no {{ font:600 12px/1 "IBM Plex Mono", monospace; color:var(--muted);
  margin-right:12px; letter-spacing:.15em; }}
section p {{ max-width:42em; }}

table {{ width:100%; border-collapse:collapse; background:var(--panel);
  border:2px solid var(--ink); margin:14px 0 18px;
  font:13px/1.5 "IBM Plex Mono", monospace; }}
th, td {{ text-align:left; padding:9px 12px; border-bottom:1px solid var(--line);
  vertical-align:top; }}
th {{ font-size:11px; letter-spacing:.1em; text-transform:uppercase;
  border-bottom:2px solid var(--ink); }}
tr:last-child td {{ border-bottom:none; }}
.tag {{ display:inline-block; font:600 10.5px/1 "IBM Plex Mono", monospace;
  letter-spacing:.12em; text-transform:uppercase; padding:4px 8px;
  border:1.5px solid currentColor; border-radius:4px; }}
.t-fail {{ color:var(--fail); }} .t-warn {{ color:var(--warn); }}
.more {{ color:var(--muted); }}
.mono-dim {{ color:var(--muted); }}
.clean {{ font:600 15px/1.6 "IBM Plex Sans", sans-serif; color:var(--pass);
  border:2px solid var(--pass); border-radius:8px; padding:14px 16px;
  background:var(--panel); max-width:42em; }}

.chain {{ background:var(--panel); border:2px solid var(--ink); border-radius:8px;
  padding:16px 18px; font:13px/1.7 "IBM Plex Mono", monospace; margin:14px 0 18px; }}
.chain b {{ letter-spacing:.05em; }}
.fine {{ font-size:13px; color:var(--muted); }}
ol.method {{ max-width:44em; padding-left:20px; }}
ol.method li {{ margin-bottom:8px; }}

footer {{ padding-top:26px; font:12.5px/1.7 "IBM Plex Mono", monospace;
  color:var(--muted); }}
footer b {{ color:var(--ink); }}

@media (max-width:720px) {{
  .figs {{ grid-template-columns:repeat(2,1fr); }}
  .stamp {{ position:static; display:inline-block; transform:rotate(-3deg);
    margin-top:20px; }}
  .doc {{ padding:20px 16px 48px; }}
  table {{ display:block; overflow-x:auto; }}
}}
@media print {{ .stamp {{ box-shadow:none; }} body {{ background:#fff; }} }}
</style>
</head>
<body>
<div class="doc">

  <div class="meta-bar">
    <span><b>SignalProof</b> · independent indicator audit</span>
    <span>Report <b>{rid}</b> · issued {issued}</span>
  </div>

  <header class="hero">
    <p class="kicker">Audit certificate</p>
    <h1>{esc(args.name)}</h1>
    <p class="sub">by {esc(args.vendor)}{" · " + esc(args.market) if args.market else ""}
    <br>Monitored {esc(w_start)} → {esc(w_end)} ({esc(days)} days)</p>
    <div class="stamp {vclass}">{esc(stamp_text)}<small>{rid}</small></div>
    <p class="verdict-line"><b>Finding:</b> {esc(verdict_line)}</p>
  </header>

  <div class="figs">{figures_html}</div>

  <section>
    <h2><span class="sec-no">01</span>Repaint analysis</h2>
    <p>Every live signal below was received and timestamped by an independent
    server the moment the indicator fired. Weeks later, the indicator's chart
    history was exported and diffed against that record. A signal that
    <b>vanished</b> was shown live but is gone from history; a <b>backfilled</b>
    signal exists in history but never fired live. Both rewrite the past.</p>
    {discrepancy_block}
  </section>

  <section>
    <h2><span class="sec-no">02</span>Live signal log (sample)</h2>
    <table>
      <thead><tr><th>Received (UTC)</th><th>Signal</th><th>Market</th>
      <th>Price</th><th>Row hash</th></tr></thead>
      <tbody>{sample_rows}</tbody>
    </table>
    <p class="fine">Showing first and last entries of {len(rows)} logged rows.
    The full log is published with this report.</p>
  </section>
  {stats_block}
  <section>
    <h2><span class="sec-no">{('04' if stats_block else '03')}</span>Chain of custody</h2>
    <div class="chain">
      Log integrity: <b class="{'pass' if chain.get('intact') else 'fail'}">{esc(chain_state)}</b><br>
      Rows verified: {chain.get('checked', 0)}<br>
      First hash: {esc(short_hash(first_hash))}<br>
      Final hash: {esc(short_hash(last_hash))}
    </div>
    <p class="fine">Each row's hash covers the previous row's hash plus its own
    fields, so editing, deleting, or inserting any past signal breaks every hash
    after it. Anyone can re-verify the published log with the open-source checker.</p>
  </section>

  <section>
    <h2><span class="sec-no">{('05' if stats_block else '04')}</span>Method</h2>
    <ol class="method">
      <li>The indicator is added to a chart exactly as a paying subscriber would use it.</li>
      <li>Alerts on its signals post to the SignalProof logger, which records server-side
          UTC timestamps in an append-only, hash-chained log.</li>
      <li>After the monitoring window, the indicator's chart history is exported from
          TradingView.</li>
      <li>The live record and the exported history are diffed bar-by-bar, per direction.</li>
      <li>Forward performance is computed only from live-recorded signals, so lookahead
          and cherry-picking are impossible by construction.</li>
    </ol>
  </section>

  <footer>
    <b>Scope &amp; disclaimer.</b> This audit verifies signal consistency and measures
    post-signal price behaviour during the stated window only. It is not investment
    advice, not an endorsement, and says nothing about future profitability.
    Findings are reproducible from the published evidence files.
    <br><br>signalproof · audit {rid} · methodology v0.1
  </footer>

</div>
</body>
</html>"""

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page)
    print(f"report    : {out}  [{verdict}]  chain "
          f"{'intact' if chain.get('intact') else 'BROKEN'}")


if __name__ == "__main__":
    main()
