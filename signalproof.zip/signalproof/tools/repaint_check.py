"""SignalProof repaint check.

Compares the live signal log (what the indicator said in real time, recorded
by the webhook server) against a TradingView chart export taken days/weeks
later (what the indicator's history claims now).

  VANISHED  = logged live, missing from today's chart  -> repaint
  APPEARED  = on today's chart inside the monitored window, never fired live
              -> backfilled signal, repaint
  MATCHED   = consistent

Usage:
  python tools/repaint_check.py \
      --live data/demo/aurora_live.csv \
      --chart data/demo/aurora_chart.csv \
      --buy-col Buy --sell-col Sell \
      --out reports/aurora_repaint.json

The chart CSV is TradingView's "Export chart data…" file: a `time` column
plus one column per plotted series. A bar "has" a signal when the cell is
non-empty/non-NaN (and non-zero unless --zero-is-signal).
"""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd

INTERVAL_SECONDS = {
    "1": 60, "3": 180, "5": 300, "15": 900, "30": 1800, "45": 2700,
    "60": 3600, "120": 7200, "180": 10800, "240": 14400,
    "1D": 86400, "D": 86400, "1W": 604800, "W": 604800,
}


def parse_time_series(s: pd.Series) -> pd.Series:
    """Normalize a time column (ISO string or unix s/ms) to UTC unix seconds."""
    if pd.api.types.is_numeric_dtype(s):
        vals = s.astype("float64")
        if vals.dropna().gt(1e12).all():
            vals = vals / 1000.0
        return vals.round().astype("Int64")
    dt = pd.to_datetime(s, utc=True, errors="coerce")
    epoch = pd.Timestamp(0, tz="UTC")
    return ((dt - epoch) // pd.Timedelta(seconds=1)).astype("Int64")


def signal_active(series: pd.Series, zero_is_signal: bool) -> pd.Series:
    active = series.notna()
    if not zero_is_signal:
        numeric = pd.to_numeric(series, errors="coerce")
        active &= ~(numeric == 0)
    return active


def classify_direction(label: str | None) -> str:
    s = (label or "").upper()
    if "BUY" in s or "LONG" in s:
        return "BUY"
    if "SELL" in s or "SHORT" in s:
        return "SELL"
    return "ANY"


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--live", required=True, help="CSV export from the logger (/signals?fmt=csv)")
    ap.add_argument("--chart", required=True, help="TradingView 'Export chart data' CSV")
    ap.add_argument("--indicator", default=None, help="Filter live log to one indicator slug")
    ap.add_argument("--buy-col", default=None, help="Chart column holding buy signals")
    ap.add_argument("--sell-col", default=None, help="Chart column holding sell signals")
    ap.add_argument("--time-col", default="time")
    ap.add_argument("--tolerance-bars", type=int, default=0,
                    help="Allow a live signal to match a chart bar +/- N bars away")
    ap.add_argument("--bar-seconds", type=int, default=None,
                    help="Bar length in seconds (else inferred from interval column)")
    ap.add_argument("--zero-is-signal", action="store_true")
    ap.add_argument("--skip-last-bars", type=int, default=1,
                    help="Ignore the newest N chart bars (possibly still forming)")
    ap.add_argument("--out", default=None, help="Write verdict JSON here")
    args = ap.parse_args()

    if not args.buy_col and not args.sell_col:
        sys.exit("Provide --buy-col and/or --sell-col (chart column names).")

    live = pd.read_csv(args.live, dtype=str)
    if args.indicator:
        live = live[live["indicator"] == args.indicator]
    if live.empty:
        sys.exit("Live log is empty after filtering — nothing to check.")
    live["bar_unix"] = parse_time_series(live["bar_time"])
    live = live.dropna(subset=["bar_unix"]).copy()
    live["direction"] = live["signal"].map(classify_direction)

    chart = pd.read_csv(args.chart)
    if args.time_col not in chart.columns:
        sys.exit(f"Chart CSV has no '{args.time_col}' column. "
                 f"Columns: {list(chart.columns)}")
    chart["bar_unix"] = parse_time_series(chart[args.time_col])
    chart = chart.dropna(subset=["bar_unix"]).sort_values("bar_unix")
    if args.skip_last_bars > 0:
        chart = chart.iloc[:-args.skip_last_bars]

    bar_seconds = args.bar_seconds
    if bar_seconds is None:
        iv = str(live["interval"].dropna().iloc[0]) if live["interval"].notna().any() else ""
        bar_seconds = INTERVAL_SECONDS.get(iv)
    if bar_seconds is None:
        diffs = chart["bar_unix"].diff().dropna()
        bar_seconds = int(diffs.mode().iloc[0]) if not diffs.empty else 3600

    active = {}
    for direction, col in (("BUY", args.buy_col), ("SELL", args.sell_col)):
        if col:
            if col not in chart.columns:
                sys.exit(f"Chart CSV has no column '{col}'. "
                         f"Columns: {list(chart.columns)}")
            mask = signal_active(chart[col], args.zero_is_signal)
            active[direction] = set(chart.loc[mask, "bar_unix"].astype(int))

    def chart_has(direction: str, t: int) -> bool:
        dirs = [direction] if direction in active else list(active)
        for d in dirs:
            for k in range(-args.tolerance_bars, args.tolerance_bars + 1):
                if t + k * bar_seconds in active.get(d, ()):
                    return True
        return False

    matched, vanished = [], []
    live_by_dir: dict[str, set[int]] = {}
    for _, r in live.iterrows():
        t = int(r["bar_unix"])
        d = r["direction"]
        live_by_dir.setdefault(d, set()).add(t)
        record = {"bar_time": r.get("bar_time"), "bar_unix": t,
                  "direction": d, "signal": r.get("signal"),
                  "price": r.get("price_raw"),
                  "received_at": r.get("received_at")}
        (matched if chart_has(d, t) else vanished).append(record)

    window_start = int(live["bar_unix"].min())
    window_end = int(live["bar_unix"].max())

    def live_has(direction: str, t: int) -> bool:
        pools = [live_by_dir.get(direction, set()), live_by_dir.get("ANY", set())]
        for pool in pools:
            for k in range(-args.tolerance_bars, args.tolerance_bars + 1):
                if t + k * bar_seconds in pool:
                    return True
        return False

    appeared = []
    for direction, bars in active.items():
        for t in sorted(bars):
            if window_start <= t <= window_end and not live_has(direction, t):
                appeared.append({
                    "bar_unix": t,
                    "bar_time": pd.Timestamp(t, unit="s", tz="UTC")
                                  .strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "direction": direction})

    n_live, n_van, n_app = len(live), len(vanished), len(appeared)
    if n_van == 0 and n_app == 0:
        verdict = "PASS"
    elif n_van + n_app <= 0:
        verdict = "WARN"
    else:
        verdict = "FAIL"

    result = {
        "tool": "signalproof.repaint_check/0.1",
        "indicator": args.indicator or str(live["indicator"].iloc[0]),
        "bar_seconds": bar_seconds,
        "monitored_window_utc": {
            "start": pd.Timestamp(window_start, unit="s", tz="UTC").strftime("%Y-%m-%dT%H:%M:%SZ"),
            "end": pd.Timestamp(window_end, unit="s", tz="UTC").strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        "counts": {"live_signals": n_live, "matched": len(matched),
                   "vanished": n_van, "appeared": n_app},
        "verdict": verdict,
        "vanished": vanished,
        "appeared": appeared,
        "notes": [
            "VANISHED: fired live (server-timestamped) but absent from the chart's history now.",
            "APPEARED: present in chart history inside the monitored window but never fired live.",
            "Either discrepancy means historical signals are not what subscribers saw in real time.",
        ],
    }

    print(f"indicator : {result['indicator']}")
    print(f"window    : {result['monitored_window_utc']['start']} -> "
          f"{result['monitored_window_utc']['end']}")
    print(f"live      : {n_live}   matched: {len(matched)}   "
          f"vanished: {n_van}   appeared: {n_app}")
    print(f"VERDICT   : {verdict}")

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(result, indent=2))
        print(f"wrote     : {args.out}")


if __name__ == "__main__":
    main()
