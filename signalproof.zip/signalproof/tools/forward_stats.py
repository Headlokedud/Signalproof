"""SignalProof forward stats.

Because every signal in the live log was recorded *before* the outcome was
known, performance computed from it is a true forward test — no lookahead,
no cherry-picking. This tool measures what happened after each logged signal.

Usage:
  python tools/forward_stats.py \
      --live data/demo/aurora_live.csv \
      --ohlc data/demo/aurora_chart.csv \
      --horizons 1,5,10,20 --cost-bps 5 \
      --out reports/aurora_stats.json

OHLC source: the same TradingView chart export works (it contains
open/high/low/close). Any CSV with time/open/high/low/close is accepted.
For convenience on your own machine you can install yfinance and use
--yf SYMBOL --yf-interval 1h instead of --ohlc.
"""
import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from repaint_check import classify_direction, parse_time_series  # noqa: F401


def load_ohlc(args) -> pd.DataFrame:
    if args.ohlc:
        df = pd.read_csv(args.ohlc)
        cols = {c.lower(): c for c in df.columns}
        for need in ("time", "open", "close"):
            if need not in cols:
                sys.exit(f"OHLC CSV needs a '{need}' column. "
                         f"Columns: {list(df.columns)}")
        out = pd.DataFrame({
            "bar_unix": parse_time_series(df[cols["time"]]),
            "open": pd.to_numeric(df[cols["open"]], errors="coerce"),
            "close": pd.to_numeric(df[cols["close"]], errors="coerce"),
        })
        return (out.dropna(subset=["bar_unix"])
                   .sort_values("bar_unix").reset_index(drop=True))
    if args.yf:
        try:
            import yfinance as yf
        except ImportError:
            sys.exit("pip install yfinance, or pass --ohlc <csv> instead.")
        hist = yf.Ticker(args.yf).history(period=args.yf_period,
                                          interval=args.yf_interval)
        hist = hist.reset_index()
        tcol = "Datetime" if "Datetime" in hist.columns else "Date"
        return pd.DataFrame({
            "bar_unix": (pd.to_datetime(hist[tcol], utc=True)
                           .astype("int64") // 10**9),
            "open": hist["Open"], "close": hist["Close"],
        }).sort_values("bar_unix").reset_index(drop=True)
    sys.exit("Provide --ohlc <csv> or --yf <symbol>.")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--live", required=True)
    ap.add_argument("--indicator", default=None)
    ap.add_argument("--ohlc", default=None)
    ap.add_argument("--yf", default=None)
    ap.add_argument("--yf-interval", default="1h")
    ap.add_argument("--yf-period", default="730d")
    ap.add_argument("--horizons", default="1,5,10,20",
                    help="Comma-separated horizons in bars after entry")
    ap.add_argument("--entry", choices=["next-open", "close"],
                    default="next-open",
                    help="next-open = enter at the open of the bar after the "
                         "signal (realistic). close = enter at signal bar close.")
    ap.add_argument("--cost-bps", type=float, default=0.0,
                    help="One-way cost in basis points; applied twice per trade")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    live = pd.read_csv(args.live, dtype=str)
    if args.indicator:
        live = live[live["indicator"] == args.indicator]
    if live.empty:
        sys.exit("Live log empty after filtering.")
    live["bar_unix"] = parse_time_series(live["bar_time"])
    live = live.dropna(subset=["bar_unix"])
    live["direction"] = live["signal"].map(classify_direction)
    live = live[live["direction"].isin(["BUY", "SELL"])]
    if live.empty:
        sys.exit("No BUY/SELL signals found (signal labels must contain "
                 "BUY/LONG or SELL/SHORT).")

    ohlc = load_ohlc(args)
    index_of = {int(t): i for i, t in enumerate(ohlc["bar_unix"])}
    horizons = [int(h) for h in args.horizons.split(",") if h.strip()]
    round_trip_cost = 2 * args.cost_bps / 10_000.0

    trades = []
    skipped = 0
    for _, r in live.iterrows():
        i = index_of.get(int(r["bar_unix"]))
        if i is None:
            skipped += 1
            continue
        if args.entry == "next-open":
            entry_i = i + 1
            if entry_i >= len(ohlc):
                skipped += 1
                continue
            entry_price = float(ohlc["open"].iloc[entry_i])
        else:
            entry_i = i
            entry_price = float(ohlc["close"].iloc[i])
        sign = 1.0 if r["direction"] == "BUY" else -1.0
        rets = {}
        for h in horizons:
            j = entry_i + h
            if j < len(ohlc):
                exit_price = float(ohlc["close"].iloc[j])
                rets[h] = sign * (exit_price / entry_price - 1.0) - round_trip_cost
        if rets:
            trades.append({"direction": r["direction"], "rets": rets})

    if not trades:
        sys.exit("No signals could be matched to OHLC bars.")

    per_h = {}
    for h in horizons:
        vals = [t["rets"][h] for t in trades if h in t["rets"]]
        if not vals:
            continue
        s = pd.Series(vals)
        per_h[str(h)] = {
            "trades": int(s.size),
            "win_rate_pct": round(float((s > 0).mean()) * 100, 1),
            "avg_return_pct": round(float(s.mean()) * 100, 3),
            "median_return_pct": round(float(s.median()) * 100, 3),
            "best_pct": round(float(s.max()) * 100, 3),
            "worst_pct": round(float(s.min()) * 100, 3),
        }

    result = {
        "tool": "signalproof.forward_stats/0.1",
        "indicator": args.indicator or str(live["indicator"].iloc[0]),
        "entry_rule": args.entry,
        "cost_bps_round_trip": 2 * args.cost_bps,
        "signals_used": len(trades),
        "signals_unmatched": skipped,
        "buy_signals": int((live["direction"] == "BUY").sum()),
        "sell_signals": int((live["direction"] == "SELL").sum()),
        "horizons_bars": per_h,
        "notes": [
            "True forward test: every signal was server-timestamped before its outcome existed.",
            "Returns are per-trade, direction-adjusted (SELL profits when price falls).",
            "No position sizing, overlap handling, or slippage beyond --cost-bps.",
        ],
    }

    print(f"indicator : {result['indicator']}  "
          f"(signals used: {len(trades)}, unmatched: {skipped})")
    print(f"entry     : {args.entry}, round-trip cost {2 * args.cost_bps:g} bps")
    print(f"{'h(bars)':>8} {'trades':>7} {'win%':>7} {'avg%':>8} {'median%':>8}")
    for h, st in per_h.items():
        print(f"{h:>8} {st['trades']:>7} {st['win_rate_pct']:>7} "
              f"{st['avg_return_pct']:>8} {st['median_return_pct']:>8}")

    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(result, indent=2))
        print(f"wrote     : {args.out}")


if __name__ == "__main__":
    main()
