"""Generate demo data for SignalProof so the full pipeline can be tested
without waiting weeks for a real monitoring window.

Creates, under data/demo/:
  aurora_live.csv / aurora_chart.csv   -> clean indicator, expect PASS
  quantum_live.csv / quantum_chart.csv -> repainting indicator, expect FAIL
     (3 live signals vanish from history, 2 signals are backfilled)

Live CSVs use the exact column layout of the logger's /signals?fmt=csv
export, including a valid hash chain.
"""
import csv
import json
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from core.chain import GENESIS, row_hash  # noqa: E402

OUT = ROOT / "data" / "demo"
LIVE_COLUMNS = ["id", "received_at", "indicator", "symbol", "exchange",
                "interval", "signal", "price_raw", "bar_time", "alert_time",
                "raw", "prev_hash", "row_hash"]


def iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def make_series(start_price: float, sigma: float, bars: int, seed: int):
    rng = random.Random(seed)
    t0 = datetime(2026, 5, 11, 0, 0, tzinfo=timezone.utc)
    out, price = [], start_price
    for i in range(bars):
        o = price
        drift = rng.gauss(0, sigma)
        c = max(o + drift, 1.0)
        h = max(o, c) + abs(rng.gauss(0, sigma * 0.5))
        low = min(o, c) - abs(rng.gauss(0, sigma * 0.5))
        out.append({"t": t0 + timedelta(hours=i), "open": round(o, 2),
                    "high": round(h, 2), "low": round(low, 2),
                    "close": round(c, 2)})
        price = c
    return out


def pick_signal_bars(bars: int, n: int, seed: int):
    rng = random.Random(seed)
    idx = sorted(rng.sample(range(8, bars - 30), n))
    sides = []
    side = "BUY"
    for _ in idx:
        sides.append(side)
        side = "SELL" if side == "BUY" else "BUY"
    return list(zip(idx, sides))


def write_live(path: Path, indicator: str, symbol: str, exchange: str,
               interval: str, series, signals):
    rows, prev = [], GENESIS
    for n, (i, side) in enumerate(signals, start=1):
        bar = series[i]
        bar_time = iso(bar["t"])
        received = iso(bar["t"] + timedelta(hours=1, seconds=2))
        price_raw = f"{bar['close']:.2f}"
        raw = json.dumps({"indicator": indicator, "signal": side,
                          "symbol": symbol, "exchange": exchange,
                          "interval": interval, "price": price_raw,
                          "bar_time": bar_time, "alert_time": received},
                         separators=(",", ":"))
        row = {"received_at": received, "indicator": indicator,
               "symbol": symbol, "exchange": exchange, "interval": interval,
               "signal": side, "price_raw": price_raw, "bar_time": bar_time,
               "alert_time": received, "raw": raw}
        h = row_hash(prev, row)
        rows.append({"id": n, **row, "prev_hash": prev, "row_hash": h})
        prev = h
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=LIVE_COLUMNS)
        w.writeheader()
        w.writerows(rows)


def write_chart(path: Path, series, chart_signals):
    """chart_signals: {bar_index: side} — what TODAY'S history claims."""
    with path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["time", "open", "high", "low", "close", "Buy", "Sell"])
        for i, bar in enumerate(series):
            side = chart_signals.get(i)
            buy = bar["close"] if side == "BUY" else ""
            sell = bar["close"] if side == "SELL" else ""
            w.writerow([iso(bar["t"]), bar["open"], bar["high"],
                        bar["low"], bar["close"], buy, sell])


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    bars = 21 * 24  # 21 days of hourly bars

    # --- Demo A: clean indicator (PASS) -----------------------------------
    series_a = make_series(2390.0, 4.0, bars, seed=7)
    sigs_a = pick_signal_bars(bars, 34, seed=11)
    write_live(OUT / "aurora_live.csv", "aurora-trend-suite", "XAUUSD",
               "OANDA", "60", series_a, sigs_a)
    write_chart(OUT / "aurora_chart.csv", series_a, dict(sigs_a))

    # --- Demo B: repainting indicator (FAIL) -------------------------------
    series_b = make_series(21500.0, 30.0, bars, seed=23)
    sigs_b = pick_signal_bars(bars, 28, seed=29)
    write_live(OUT / "quantum_live.csv", "quantum-buysell-pro", "NAS100USD",
               "OANDA", "60", series_b, sigs_b)

    chart_b = dict(sigs_b)
    vanish = [sigs_b[4][0], sigs_b[12][0], sigs_b[21][0]]
    for i in vanish:
        del chart_b[i]                      # losers scrubbed from history
    inside = sorted(set(range(sigs_b[0][0] + 1, sigs_b[-1][0] - 1))
                    - {i for i, _ in sigs_b})
    rng = random.Random(31)
    for i in rng.sample(inside, 2):
        chart_b[i] = rng.choice(["BUY", "SELL"])  # winners painted in later
    write_chart(OUT / "quantum_chart.csv", series_b, chart_b)

    print("demo data written to", OUT)
    print("  aurora-trend-suite : 34 live signals, history consistent (expect PASS)")
    print("  quantum-buysell-pro: 28 live signals, 3 vanished + 2 backfilled (expect FAIL)")


if __name__ == "__main__":
    main()
