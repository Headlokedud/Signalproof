# SignalProof

Independent, automated verification for TradingView indicators.

Every paid indicator claims "non-repaint". SignalProof turns that claim into
evidence: it records an indicator's signals **live** on an independent server,
then diffs that record against the indicator's chart history weeks later.
Signals that vanished or were backfilled = repaint, proven with timestamps.
Because the live log is captured before outcomes exist, it also doubles as a
true forward test of performance.

## What's in the box

```
server/main.py        FastAPI webhook logger (append-only, hash-chained SQLite)
tools/repaint_check.py   Live log vs chart-history diff -> PASS/FAIL verdict
tools/forward_stats.py   Honest post-signal returns (win rate, expectancy)
tools/make_report.py     Renders the public HTML audit certificate
tools/demo_data.py       Generates two demo audits (one clean, one repainting)
pine/                  Pine v6 wrapper + TradingView alert setup guide
reports/               Generated report cards land here
```

## Quickstart — see a finished audit in 2 minutes

```bash
pip install -r requirements.txt
python tools/demo_data.py
./run_demo.sh
```

Open `reports/aurora-trend-suite.html` (PASS) and
`reports/quantum-buysell-pro.html` (FAIL — 3 signals scrubbed, 2 backfilled).

## Running a real audit

1. **Start the logger**
   ```bash
   SP_SECRET="long-random-string" uvicorn server.main:app --host 0.0.0.0 --port 8000
   ```
   For testing, expose it with `ngrok http 8000`. For a real multi-week window,
   deploy to Railway/Render/Fly or a small VPS (TradingView needs a stable
   HTTPS URL on port 443/80). Back up `signalproof.db`.

2. **Wire up alerts** — follow `pine/ALERT_SETUP.md` (your own scripts use the
   Pine wrapper; third-party invite-only scripts use UI alerts with the JSON
   message template). Visit `https://<host>/` to watch signals arrive.

3. **Wait 2–4 weeks.** This is the moat: an audit can't be faked or rushed.

4. **Export both sides**
   - Live log: `https://<host>/signals?indicator=<slug>&fmt=csv`
   - Chart history: TradingView → Export chart data… (same chart/timeframe)

5. **Run the pipeline**
   ```bash
   python tools/repaint_check.py --live live.csv --chart chart.csv \
       --indicator <slug> --buy-col Buy --sell-col Sell \
       --out reports/<slug>_repaint.json

   python tools/forward_stats.py --live live.csv --ohlc chart.csv \
       --indicator <slug> --horizons 1,5,10,20 --cost-bps 5 \
       --out reports/<slug>_stats.json

   python tools/make_report.py --indicator <slug> --name "Display Name" \
       --vendor "Vendor" --market "OANDA:XAUUSD · 1H" \
       --live live.csv --repaint reports/<slug>_repaint.json \
       --stats reports/<slug>_stats.json --out reports/<slug>.html
   ```

6. **Publish** the HTML report plus the evidence files (live CSV, chart CSV,
   verdict JSON). `GET /verify/<slug>` proves the hash chain is intact.

## Useful endpoints

- `GET /` — live dashboard
- `GET /indicators` — slugs, counts, first/last seen
- `GET /signals?indicator=<slug>&fmt=csv` — evidence export
- `GET /verify/<slug>` — recompute the hash chain

## Honest limitations (state these in reports)

- "Once per bar close" alerts test **confirmed-bar** repainting — the claim
  sellers actually make. Intrabar flicker is a separate, stricter test.
- Data-feed differences between your chart and the vendor's demo can cause
  borderline mismatches; that's what `--tolerance-bars` and WARN are for.
- A PASS means *history is honest*, not *the indicator is profitable*. The
  forward stats section is what speaks to performance.
- Don't publish accusations beyond what the diff shows. The report's language
  is factual by design — keep it that way.

## Business notes

- **Founding offer:** free audits for the first 5–10 sellers in exchange for a
  testimonial and the badge on their page. Then charge per audit (a multi-week
  monitored certificate justifies real pricing) and a monthly fee to keep the
  badge "live".
- **Content loop:** every audit is a post. Aggregate findings ("X of Y popular
  indicators failed") are publishable without naming anyone while you build
  the process.
- Your own indicators get audited first — the badge strengthens your existing
  TradingView funnel even if nobody else ever pays.

## Roadmap

- Embeddable SVG badge linking to the report
- Index page listing all audits (static site)
- Intrabar mode (log `freq_all` alerts, flag flicker)
- Multi-symbol audit batches; uptime/gap tracking for the monitoring window
