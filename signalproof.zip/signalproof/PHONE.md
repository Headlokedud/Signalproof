# Running SignalProof from a phone only

Short version: 100% of this works from a phone. ~90% is comfortable, ~10% is
fiddly-but-fine. The one unlock that makes it possible: **GitHub Codespaces**
gives you a full Linux terminal inside your phone browser, free tier included.

Division of labor: **you tap, Claude computes.** Anything involving Python
(repaint check, stats, report generation) — send the CSVs to Claude in chat
and get the finished report back.

---

## A. Naturally phone-native (no tricks needed)

- **Railway dashboard** — responsive web app: deploy, volume, variables, domain
- **Monitoring** — open `https://<your-app>/` in the browser; signals appear live
- **Weekly evidence backup** — open `/signals?fmt=csv`; the CSV downloads to
  your phone's Files
- **Editing the landing page placeholders** — GitHub mobile web → file →
  pencil icon → edit → commit
- **All outreach** — TradingView comments/DMs, X, Discord: phone is the
  *better* device for this
- **Analysis & reports** — upload live CSV + chart CSV to Claude, get the
  finished report card back

## B. Phone via Codespaces (one-time repo setup, ~15 min)

1. Browser → github.com → **+** → **New repository** → name `signalproof` →
   **Public** → Create.
   (Public is deliberate: "tools are open source" is part of the trust pitch,
   the secret never lives in the repo, and free GitHub Pages needs a public
   repo.)
2. On the repo page → green **Code** button → **Codespaces** tab →
   **Create codespace on main**. VS Code opens in the browser. Rotate to
   landscape.
3. Get the project in: in the file explorer, **long-press** an empty area →
   **Upload…** → pick `signalproof.zip` from your phone's Files.
4. Open the terminal (☰ menu → Terminal → New Terminal) and paste:

   ```bash
   unzip -o signalproof.zip && cp -a signalproof/. . && rm -rf signalproof signalproof.zip
   git add -A && git commit -m "SignalProof v0.1" && git push
   ```

5. Generate your webhook secret while you're here:

   ```bash
   openssl rand -hex 24
   ```

   Copy it somewhere safe (you'll paste it into Railway and into every
   TradingView alert URL).
6. Later, run the post-deploy curl tests from DEPLOY.md in this same terminal.
7. Done for now: Codespaces tab → **⋯** → **Stop codespace** (free quota is
   ~120 core-hours/month — plenty).

## C. Railway on phone (~10 min)

railway.com in the browser → log in with GitHub → **New Project** →
**Deploy from GitHub repo** → `signalproof`. Then per DEPLOY.md: attach a
**Volume** at `/data`, add variable `SP_SECRET`, **Generate Domain**.
Buttons are small — landscape + zoom. Everything works.

## D. TradingView on phone (the fiddly 10%)

The webhook URL field lives in the alert dialog on the **web platform**
(paid plans). The mobile app's alert editor may not expose it, so use:

1. Phone browser → tradingview.com → log in → browser menu →
   **Request desktop site**.
2. Open the chart, add the indicator, create the alert:
   Condition → the script's Buy/Sell condition → **Once per bar close** →
   **Notifications tab** → tick **Webhook URL** → paste
   `https://<your-domain>/webhook/<secret>` → paste the JSON message from
   `pine/ALERT_SETUP.md`.
3. Pinch-zoom as needed. ~10 minutes per audit, one time per script.
4. Delivery check: the alert log (bell icon) has a **Webhook status** column —
   glance at it after the first signal fires.

**Phone-friendly shortcut for your own scripts:** skip the Pine wrapper
entirely. If your published indicators already have signal plots or
alertconditions, create UI alerts on those (Path B in ALERT_SETUP.md) — zero
code editing needed. The wrapper is an optimization for whenever you next
have PC access.

**End of audit window (weeks later):** same desktop-mode browser → chart menu
→ **Export chart data…** → CSV lands in Files → send it plus the live CSV
(from `/signals?indicator=<slug>&fmt=csv`) to Claude → finished report comes
back.

## E. Publishing the landing page (all mobile web, ~3 min)

The `docs/` folder already contains the landing page + both sample reports.

1. Repo → **Settings** → **Pages** → Source: *Deploy from a branch* →
   `main` / `/docs` → Save.
2. ~2 minutes later your site is live at
   `https://<your-username>.github.io/signalproof/`
3. Fill in the placeholders: repo → `docs/index.html` → pencil icon → edit the
   four `EDIT-ME` spots (email ×2, X handle, pricing) → Commit changes.

## F. Honest friction list

- Codespaces on a phone keyboard is usable for *pasting* commands, miserable
  for *writing* code. Never write code there — ask Claude, paste the result.
- TradingView desktop-mode on a phone screen is cramped. It's a one-time
  10-minute job per audit; survivable.
- If an upload or button genuinely won't cooperate on mobile, that single step
  can wait for any 30 minutes of PC access — nothing in the workflow is
  time-critical except keeping the Railway server running, which needs no
  touching at all once deployed.
