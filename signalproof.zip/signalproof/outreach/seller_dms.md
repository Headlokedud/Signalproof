# Founding-audit outreach pack

## Where to find the first 10 targets (30 min of scrolling)

1. TradingView → Community Scripts → filter **invite-only**, sort by popularity
   in your niches (ICT/SMC, gold, indices). Note authors with active comment
   sections — engaged authors reply to DMs.
2. Whop / Gumroad trading categories — community owners selling indicator
   access. They live and die by conversion rate, which is your pitch.
3. X/fintwit: search "non repaint" + "indicator" — anyone marketing with that
   phrase is selling exactly the claim you verify.
4. Your own customers and Pine author mutuals first. Warm beats cold 10:1.

## Rules of engagement (these keep you safe and credible)

- **Never imply suspicion.** You are offering proof, not threatening exposure.
  The audit is opt-in; the tone is peer-to-peer.
- Lead with what they get (badge, conversion, differentiation), not with your
  product story.
- One short message. No links walls. Offer the sample report only when they
  reply or in a single link.
- Founding terms everywhere: free audit, they see results first, only a PASS
  goes public, and only with consent.
- Track everything in a sheet: name, channel, date sent, reply, status.

---

## DM 1 — the standard founding offer (default opener)

> Hey [NAME] — fellow Pine author here ([YOUR TV HANDLE]). I'm starting an
> independent audit service for indicators: I record a script's live signals
> on a third-party server for ~3 weeks, then diff them against the chart
> history. Result is a public "Verified · no repaint" report card.
>
> I'm doing the first 10 audits free for established authors. You'd see the
> result before anyone else, and only a PASS gets published. Interested in
> [SCRIPT NAME] being one of the founding ten?

## DM 2 — big vendor with an active Discord

> Hey [NAME] — I run independent repaint audits for TradingView scripts
> (live-recorded signals vs. later chart history, multi-week window, published
> evidence). For a community your size, a third-party Verified badge is the
> kind of thing that closes fence-sitters in #questions.
>
> First 10 audits are free, you see results first, only a PASS is published.
> Want [SCRIPT NAME] in the founding batch? Sample report: [LINK]

## DM 3 — small or new seller

> Hey [NAME] — saw [SCRIPT NAME], clean work. Honest observation: every
> seller in this category claims non-repaint, so the claim itself is worth
> nothing. I run independent audits that turn it into evidence — live signal
> log on a neutral server, diffed against history after 3 weeks, public
> report card.
>
> I'm giving the first 10 audits away free to build the registry. As a newer
> seller you'd be one of very few with third-party proof. Interested?

## DM 4 — open-source author going paid

> Hey [NAME] — your open-source [SCRIPT NAME] is solid. If you take it
> invite-only, the first thing you lose is the "read the code yourself" trust.
> My audit replaces it: independent live-signal record vs. chart history,
> public Verified report. First 10 are free. Worth a look before launch?

## DM 5 — vendor publicly accused of repainting in comments

(Use only the redemption angle. Zero reference to guilt.)

> Hey [NAME] — I build independent verification for TradingView scripts. I
> noticed repaint questions keep coming up in your comments — that happens to
> almost every signal script, fair or not, because buyers have no way to
> check. An independent audit settles it with data instead of replies: 3
> weeks of live-recorded signals diffed against history, evidence published.
> Founding audits are free and you see results first. Want to put the
> question to bed?

## DM 6 — ICT/SMC-niche author (peer language)

> Hey [NAME] — fellow ICT-tools builder ([YOUR TV HANDLE], I publish
> [YOUR SCRIPT]). FVG/OB scripts get accused of repainting more than any
> other category because the levels redraw by design — which makes a real
> audit worth more here than anywhere. I log a script's live alerts on an
> independent server for ~3 weeks and diff against the chart after. Public
> Verified report if it holds. Doing the first 10 free — want in?

## DM 7 — the follow-up (4–6 days after no reply)

> Quick bump — the founding batch is filling up ([N] of 10 spots left). Zero
> cost, ~3 weeks of passive monitoring, you see the result before anyone.
> If it's a no, all good — happy to keep you posted when paid audits open.

## DM 8 — Whop/community owner (conversion angle)

> Hey [NAME] — for communities selling indicator access, the #1 pre-sale
> question is some version of "is this legit?" I run independent audits:
> live-recorded signals vs. chart history over 3 weeks, public report card,
> raw evidence attached. A Verified badge on your sales page answers the
> question before it's asked. First 10 audits free — want [PRODUCT] in?

## DM 9 — the skeptic reply ("what's the catch / are you trying to expose me?")

> Totally fair question. The catch is just that I'm building a registry and
> need credible scripts in it — that's why founding audits are free. Terms in
> plain words: you see the full result first; a PASS is only published with
> your consent; a fail stays private, you get the evidence, fix it, and
> re-audit. I never publish anything about a founding script without consent.
> Methodology and tools are open source: [LINK]

## DM 10 — PASS delivery (the moment that produces the testimonial)

> [NAME] — audit's done: [SCRIPT NAME] passed. [N] live signals over
> [D] days, zero discrepancies, full report here: [REPORT LINK]
>
> Two things, both optional: 1) a one-line testimonial I can put on the site,
> and 2) the badge embed for your script page / Discord — it links straight
> to the report. Congrats, you're one of the first verified scripts on
> TradingView. Anyone you'd vouch for who should be in the next batch?

---

## After the founding batch

- Raise to paid ($249/audit, $19/mo badge — adjust to what the DMs taught you).
- Every PASS report is a post; every batch is a "X of Y scripts verified"
  aggregate post. Never name a failing script from the founding batch.
- The ask at the end of DM 10 (referrals) is the growth loop. Verified sellers
  recruiting peers beats any cold DM.
